
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;
import java.util.Map;
import java.util.TreeMap;
/*
 * Models a simple ECommerce system. Keeps track of products for sale, registered customers, product orders and
 * orders that have been shipped to a customer
 */
public class ECommerceSystem
{
    private Map<String,Product>  products = new TreeMap<String,Product>();
    private ArrayList<Customer> customers = new ArrayList<Customer>();	
    
    private Map<String, Integer> statsProducts = new TreeMap<String, Integer>();
    private ArrayList<ProductOrder> orders   = new ArrayList<ProductOrder>();
    private ArrayList<ProductOrder> shippedOrders   = new ArrayList<ProductOrder>();
    
    // These variables are used to generate order numbers, customer id's, product id's 
    private int orderNumber = 500;
    private int customerId = 900;
    private int productId = 700;
    
    // Random number generator
    Random random = new Random();
    
    public ECommerceSystem()
    {
    	// NOTE: do not modify or add to these objects!! - the TAs will use for testing
    	// If you do the class Shoes bonus, you may add shoe products
    	
    	// Create some products. Notice how generateProductId() method is used
      try
      {
    	  products = productMap("products.txt");
      }
      catch(IOException e)
      {
        System.out.println(e.getMessage());
        System.exit(1);
      }

      //Creates a map with productId's as key and the number times product ordered as 0
      statsProducts = statsMap();
    	
    	// Create some customers. Notice how generateCustomerId() method is used
    	customers.add(new Customer(generateCustomerId(),"Inigo Montoya", "1 SwordMaker Lane, Florin"));
    	customers.add(new Customer(generateCustomerId(),"Prince Humperdinck", "The Castle, Florin"));
    	customers.add(new Customer(generateCustomerId(),"Andy Dufresne", "Shawshank Prison, Maine"));
    	customers.add(new Customer(generateCustomerId(),"Ferris Bueller", "4160 Country Club Drive, Long Beach"));
    }
    
    private Map<String,Product> productMap(String filename) throws FileNotFoundException, IOException
    {
      File filein = new File(filename);
      Scanner in = new Scanner(filein);
      Map<String,Product> prods = new TreeMap<String,Product>();
      while(in.hasNextLine())
      {
        String category =in.nextLine();
        String name = in.nextLine();
        double price = in.nextDouble();
        String prodId = generateProductId();
        in.nextLine(); //Remove newline character at the end of nextDouble()
        if(category.equalsIgnoreCase("BOOKS"))
        {
          String[] stock = in.nextLine().split(" "); //The two stock numbers in a list
          int paperbackStock =Integer.parseInt(stock[0]);
          int hardcoverStock =Integer.parseInt(stock[1]);

          //list for the 5th additional line
          String[] additonal = in.nextLine().split(":");
          String title = additonal[0];
          String author = additonal[1];
          int year = Integer.parseInt(additonal[2]);

          //constructor for books
          prods.put(prodId,(new Book(name,prodId,price,paperbackStock,hardcoverStock,title,author,year)));
        }
        else if(category.equalsIgnoreCase("SHOES"))
        {
          //The 4th line of stock for the will be in thre order of total, blackShoesStock in increaing size order
          // and brownShoesSock in increasing order with the total of 11 numbers
          String[] stock = in.nextLine().split(" ");
          int totalStock = Integer.parseInt(stock[0]);
          int[] blackShoesStock = {Integer.parseInt(stock[1]), Integer.parseInt(stock[2]), Integer.parseInt(stock[3]), Integer.parseInt(stock[4]), Integer.parseInt(stock[5])};
          int[] brownShoesStock = {Integer.parseInt(stock[6]), Integer.parseInt(stock[7]), Integer.parseInt(stock[8]), Integer.parseInt(stock[9]), Integer.parseInt(stock[10])};
          in.nextLine();//Blank additional line
          //Constructor for shoes
          prods.put(prodId,(new Shoes(name, prodId,price,totalStock,blackShoesStock,brownShoesStock)));
        }
        else
        {
          //Any Non-Book and Non-shoes
          int stock = in.nextInt();
          in.nextLine(); //Remove newline character at the end of the nextInt()
          in.nextLine();//Blank Additional line
          //Constructor for Non-Book and Non-shoes
          prods.put(prodId,(new Product(name,prodId,price, stock,Product.Category.valueOf(category))));
        }
      }
      in.close();
      return prods;
    }

    private Map<String, Integer> statsMap()
    {
      Map<String, Integer> stats = new TreeMap<String, Integer>();
      for(String prodId: products.keySet())
      {
        stats.put(prodId,0);
      }
      return stats;
    } 

    private String generateOrderNumber()
    {
    	return "" + orderNumber++;
    }

    private String generateCustomerId()
    {
    	return "" + customerId++;
    }
    
    private String generateProductId()
    {
    	return "" + productId++;
    }
    
    public void printAllProducts()
    {
    	for (String prodId : products.keySet())
    		(products.get(prodId)).print();
    }
    
    // Print all products that are books. See getCategory() method in class Product
    public void printAllBooks()
    {
    	for (String prodId : products.keySet())
      {
        Product prod = products.get(prodId);
        if(prod.getCategory()==Product.Category.BOOKS)
        {
          prod.print();
        }
      }
    }
    
    // Print all current orders
    public void printAllOrders()
    {
    	for(ProductOrder order : orders)
      {
        order.print();
      }
    }
    // Print all shipped orders
    public void printAllShippedOrders()
    {
    	for(ProductOrder order : shippedOrders)
      {
        order.print();
      }
    }
    
    // Print all customers
    public void printCustomers()
    {
    	for(Customer cust : customers)
      {
        cust.print();
      }
    }
    /*
     * Given a customer id, print all the current orders and shipped orders for them (if any)
     */
    public void printOrderHistory(String customerId)
    {
      // Make sure customer exists - check using customerId
    	// If customer does not exist throw UnknownCustomerException
    	// see video for an appropriate error message string
    	// ... code here
    	Customer currentCust = getCustomer(customerId);
      if (currentCust == null)
      {
        throw new UnknownCustomerException("Customer "+ customerId + " Not Found");
      }
    	// Print current orders of this customer 
    	System.out.println("Current Orders of Customer " + customerId);
    	// enter code here
    	for(ProductOrder currentOrder : orders)
      {
        if((currentOrder.getCustomer().getId()).equals(customerId))
        {
          currentOrder.print();
        }
      }
    	// Print shipped orders of this customer 
    	System.out.println("\nShipped Orders of Customer " + customerId);
    	//enter code here
    	for(ProductOrder currentShippedOrder : shippedOrders)
      {
        if((currentShippedOrder.getCustomer().getId()).equals(customerId))
        {
          currentShippedOrder.print();
        }
      }
    }
    
    public String orderProduct(String productId, String customerId, String productOptions)
    {
    	// First check to see if customer object with customerId exists in array list customers
    	// if it does not, throw unknownCustomerException (see video for appropriate error message string)
    	// else get the Customer object
      Customer cust = getCustomer(customerId);

      if(cust == null)
      {
        throw new UnknownCustomerException("Customer " + customerId + " Not Found");
      }

    	// Check to see if product object with productId exists in map of products
    	// if it does not throw new unknownProductException
    	// else get the Product object 
      Product newProd = null;
      if(products.containsKey(productId))
      {
        newProd = products.get(productId);
      }
    	else
      {
        throw new UnknownProductException("Product " + productId + " Not Found");
      }

    	// Check if the options are valid for this product (e.g. Paperback or Hardcover or EBook for Book product)
    	// See class Product and class Book for the method vaidOptions()
    	// If options are not valid throw a new InvalidProductOptionException
    	if(!(newProd.validOptions(productOptions)))
      {
        throw new InvalidProductOptionException("Product " + newProd.getName() + " ProductId " + productId + " Invalid Options: " + productOptions);
      }
    	// Check if the product has stock available (i.e. not 0)
    	// See class Product and class Book for the method getStockCount()
    	// If no stock available throw productOutOfStockException
    	if((newProd.getStockCount(productOptions))<=0)
      {
        throw new ProductOutOfStockException("Product " + productId + " Is Not In Stock");
      }
      // Create a ProductOrder, (make use of generateOrderNumber() method above)
    	// reduce stock count of product by 1 (see class Product and class Book)
    	// Add to orders list and return order number string
      ProductOrder newOrder = new ProductOrder(generateOrderNumber(),newProd,cust,productOptions);
    	orders.add(newOrder);
      statsProducts.replace(productId,statsProducts.get(productId)+1);
      newProd.reduceStockCount(productOptions);
    	return "Order #"+(newOrder).getOrderNumber(); // replace this line
    }
    
    /*
     * Create a new Customer object and add it to the list of customers
     */
    
    public void createCustomer(String name, String address)
    {
    	// Check name parameter to make sure it is not null or ""
    	// If it is not a valid name throw a new InvalidCustomerNameException
    	// Repeat this check for address parameter
    	if(name==null || name.equals(""))
      {
        throw new InvalidCustomerNameException("Invalid Customer Name");
      }

      if(address==null || address.equals(""))
      {
        throw new InvalidCustomerAddressException("Invalid Customer Address");
      }
    	// Create a Customer object and add to array list
      customers.add(new Customer(generateCustomerId(),name,address));
    }
    
    public ProductOrder shipOrder(String orderNumber)
    {
      // Check if order number exists first. If it doesn't, throw new InvalidOrderNumberException
    	// Retrieve the order from the orders array list, remove it, then add it to the shippedOrders array list
    	// return a reference to the order
      for(int i=0; i<orders.size(); i++)
      {
        ProductOrder ord = orders.get(i);
        //If order number exists remove from ArrayList order and add to ArrayList shippedOrders
        //Return the ProductOrder object 
        if((ord.getOrderNumber()).equals(orderNumber))
        {
          orders.remove(i);
          shippedOrders.add(ord);
          return ord;
        }
      }
      //If order number not found
      throw new InvalidOrderNumberException("Order " + orderNumber + " Not Found");
    }
    
    /*
     * Cancel a specific order based on order number
     */
    public void cancelOrder(String orderNumber)
    {
      // Check if order number exists first. If it doesn't, throw a new InvalidOrderNumberException
      int sizeOrders = orders.size();
      for(int i=0; i<orders.size(); i++)
      {
        //If the order number is found remove from Arraylist and return true
        if(((orders.get(i)).getOrderNumber()).equals(orderNumber))
        {
          orders.remove(i);
          String productId = orders.get(i).getProduct().getId();
          statsProducts.replace(productId,statsProducts.get(productId)-1);
        }
      }
      //if not found throw new InvalidOrderNumberException
      if(orders.size()!=(sizeOrders-1))
      {
        throw new InvalidOrderNumberException("Order " + orderNumber + " Not Found");
      }
    }
    
    // Sort products by increasing price
    public void sortByPrice()
    {
      ArrayList<Product> prods = new ArrayList<Product>();//Temp ArrayList

      //Adding all items to the temp ArrayList
      for(String prodId: products.keySet())
      {
        prods.add(products.get(prodId));
      }

      //sorting the ArrayList
  	  Collections.sort(prods);

      //printing the ArrayList
      for(Product prod: prods)
      {
        prod.print();
      }
    }
    
    
    // Sort products alphabetically by product name
    public void sortByName()
    {
      ArrayList<Product> prods = new ArrayList<Product>();//Temp ArrayList

      //Adding all items to the temp ArrayList
      for(String prodId: products.keySet())
      {
        prods.add(products.get(prodId));
      }

  	  Collections.sort(prods, new ProductNameComparator());

      //printing the ArrayList
      for(Product prod: prods)
      {
        prod.print();
      }
    }
    
        
    // Sort products alphabetically by product name
    public void sortCustomersByName()
    {
  	  Collections.sort(customers);
    }

    //print sorted books by year if the author exists, else sets an error message
    public void printBooksByAuthor(String author)
    {
  	  ArrayList<Book> books = new ArrayList<Book>();
      //This for loop adds all the books in the product map into a new arraylist
      for (String prodId: products.keySet())
      {
        //checks if the product is a book
        Product prod = products.get(prodId);
        if(prod.getCategory()==Product.Category.BOOKS)
        {
          Book bookProd = (Book)prod;
          //checks if the book is written by the given author
          if((bookProd.getAuthor()).equalsIgnoreCase(author))
            books.add(bookProd);
        }
      }
      //Checks if the author has a book
      if(books.size()==0)
      {
        throw new UnknownAuthorException("The Author "+ author + " Not Found");
      }
      else
      {
        Collections.sort(books);
        //Print all books
        for(Book aBook: books)
        {
          aBook.print();
        }
      }
    }
    
    //This prints all valid product options
    public String printValidOptions(String productId)
    {
      if(!products.containsKey(productId))
      {
        throw new UnknownProductException("Product "+ productId + " Not Found");
      }
      Product prod = products.get(productId);

      String valid = ""; //returns blank line if non-Book and non-shoes
      //prints valid options depending on class of product
      if(prod.getCategory()==Product.Category.BOOKS)
      {
        //Check for hardcover stock
        if(prod.validOptions("Hardcover") && prod.getStockCount("Hardcover")>0) 
          valid += " Hardcover";

        //Check for paperback stock
        if(prod.validOptions("Paperback") && prod.getStockCount("Paperback")>0)
          valid += " Paperback";

        //Check for EBook stock
        if(prod.validOptions("EBook") && prod.getStockCount("EBook")>0)
          valid += " EBook";
      }
      else if(prod.getCategory()==Product.Category.SHOES)
      {
        //Check for stock of the black shoe sizes
        for(int i=6; i<=10; i++)
        {
          if(prod.getStockCount(i+"Black")>0)
          {
            valid += " " + i;
          }
        }
        //If sizes of black shoes are avalible
        if(valid!="")
          valid += " Black";

        //Check for stock of the brown shoe sizes
        for(int i=6; i<=10; i++)
        {
          if(prod.getStockCount(i+"Brown")>0)
          {
            valid += " " + i;
          }
        }
        //If sizes of brown shoes are avalible
        if(valid!="")
          valid += " Brown";
      }
      return valid;
    }

    //Add product to customer's cart
    public void addToCart(String productId,String customerId, String prodOptions)
    {
      
      //Checks if product exists, if prodOptions is valid and if there is stock avalible
      if(!products.containsKey(productId))
      {
        throw new UnknownProductException("Product "+ productId + " Not Found");
      }
      
      Product prod = products.get(productId);
      
      if(!prod.validOptions(prodOptions))
      {
        throw new InvalidProductOptionException("Product " + prod.getName() + " ProductId " + productId + " Invalid Options: " + prodOptions);
      }
      if(prod.getStockCount(prodOptions)<=0)
      {
        throw new ProductOutOfStockException("Product "+productId+" Is Not In Stock");
      }
      //Checks if customer exists
      Customer cust = getCustomer(customerId);
      if(cust==null)
      {
        throw new UnknownCustomerException("Customer "+ customerId + " Not Found");
      }
      //Adds to customers cart
      Cart cart = cust.getCart();
      cart.add(prod,prodOptions);
  }

  //Removes the first product added which matches the productId from customers cart
  public void removeCartItem(String productId, String customerId)
  {
    //Checks if customer exists
    Customer cust = getCustomer(customerId);
    if(cust==null)
    {
      throw new UnknownCustomerException("Customer "+ customerId + " Not Found");
    }

    //Checks if product exists, if prodOptions is valid and if there is stock avalible
    if(!products.containsKey(productId))
    {
      throw new UnknownProductException("Product "+ productId + " Not Found");
    }
    Product prod = products.get(productId);

    Cart custCart = cust.getCart();

    //Checks if item in the cart and throw unknownCartItemException
    int size = custCart.getList().size();
    custCart.removeItem(prod);
    if(size-1 != custCart.getList().size())
    {
      throw new UnknownCartItemException("Product " + productId + " Not Found In Cart Of Customer "+ customerId);
    }
  }

  //Prints all the items currently in a users cart
  public void printCart(String customerId)
  {
    //Checks if customer exists
    Customer cust = getCustomer(customerId);
    if(cust==null)
    {
      throw new UnknownCustomerException("Customer "+ customerId + " Not Found");
    }
    cust.getCart().print();
  }

  //Orders all the items in a customer's cart and if customer dose not exist throws new UnknowCustomerException
  public void orderAllCartItems(String customerId)
  {
    //Checks if the customer exists
    Customer cust = getCustomer(customerId);
    if(cust==null)
    {
      throw new UnknownCustomerException("Customer "+ customerId + " Not Found");
    }
    Cart custCart = cust.getCart();
    //Orders the products one at a time
    for(CartItem item: custCart.getList())
    {
      System.out.println(orderProduct(item.getProduct().getId(), customerId, item.getProductOptions()));
    }

    //Remove all items from cart
    custCart.removeAllItems();
  }

  //Helper method
  public Customer getCustomer(String customerId)
  {
    for(Customer cust : customers)
    {
      if((cust.getId()).equals(customerId))
      {
        return cust;
      }
    }
    return null;
  }

  //This method sorts the stats map
  public void sortStats()
  {

  }

  public void printAllStats()
  {
    for(String productId: statsProducts.keySet())
    {
      Product prod = products.get(productId);
      System.out.printf("\nName: %-20s Id: %-5s NumberOrdered: %-16s",prod.getName(),productId,statsProducts.get(productId));
    }
  }
}

class UnknownCustomerException extends RuntimeException
{
  public UnknownCustomerException()
  {
  }
  public UnknownCustomerException(String message)
  {
    super(message);
  }
}

class UnknownProductException extends RuntimeException
{
  public UnknownProductException()
  {
  }
  public UnknownProductException(String message)
  {
    super(message);
  }
}

class InvalidProductOptionException extends RuntimeException
{
  public InvalidProductOptionException()
  {
  }
  public InvalidProductOptionException(String message)
  {
    super(message);
  }
}

class ProductOutOfStockException extends RuntimeException
{
  public ProductOutOfStockException()
  {
  }
  public ProductOutOfStockException(String message)
  {
    super(message);
  }
}

class InvalidCustomerNameException extends RuntimeException
{
  public InvalidCustomerNameException()
  {
  }
  public InvalidCustomerNameException(String message)
  {
    super(message);
  }
}

class InvalidCustomerAddressException extends RuntimeException
{
  public InvalidCustomerAddressException()
  {
  }

  public InvalidCustomerAddressException(String message)
  {
    super(message);
  }
}

class InvalidOrderNumberException extends RuntimeException
{
  public InvalidOrderNumberException()
  {
  }
  public InvalidOrderNumberException(String message)
  {
    super(message);
  }
}

class UnknownAuthorException extends RuntimeException
{
  public UnknownAuthorException()
  {
  }
  public UnknownAuthorException(String message)
  {
    super(message);
  }
}

class UnknownCartItemException extends RuntimeException
{
  public UnknownCartItemException()
  {
  }

  public UnknownCartItemException(String message)
  {
    super(message);
  }
}

