
import java.util.*;
public class Cart
{
    private LinkedList<CartItem> items;
    
    //Construtor method of empty cart object
    public Cart()
    {
        this.items = new LinkedList<CartItem>();
    }

    //returns the list
    public LinkedList<CartItem> getList()
    {
        return items;
    }

    //Adds items to the cart
    public void add(Product prod, String prodOptions)
    {
        items.addLast(new CartItem(prod,prodOptions));
    }

    //This removes the first product 
    public void removeItem(Product prod)
    {
        ListIterator<CartItem> iter = items.listIterator();
        while(iter.hasNext())
        {
            CartItem item = iter.next();
            if((item.getProduct()).equals(prod))
            {
                iter.remove();
                break;
            }
        }
    }

    public void removeAllItems()
    {
        items.clear();
    }

    //This prints all the CartItems in the cart
    public void print()
    {
        for(CartItem item: items)
        {
            item.print();
        }
    }
}