
import java.util.Comparator;
/*
 * The compartor sorting alphebetically by product name
 */

public class ProductNameComparator implements Comparator<Product>
{
    // Sort Products by name
    public int compare(Product a, Product b)
    {
        return (a.getName()).compareTo(b.getName());
    }
}