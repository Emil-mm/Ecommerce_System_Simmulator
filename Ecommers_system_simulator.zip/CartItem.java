
public class CartItem
{
    private Product prod;
    private String prodOptions;

    //Constructor method for object Cart Object
    public CartItem(Product prod, String prodOptions)
    {
        this.prod = prod;
        this.prodOptions = prodOptions;
    }

    public Product getProduct()
    {
        return prod;
    }

    public String getProductOptions()
    {
        return prodOptions;
    }

    //Prints the product information of the cartItem and it's options
    public void print()
    {
        prod.print();
    }
}