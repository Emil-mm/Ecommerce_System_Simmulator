
/*
 * A shoe is a product that has additional options such as sizes(6, 7, 8, 9, 10) and colors(Black and Brown)
 * 
 */
public class Shoes extends Product
{
    //Inherited stockCount becomes the total amount of the shoes
    //Index[0]: Stock of size 6 , Index[1]: Stock of size 7, Index[2]: Stock of size 8, Index[3]: Stock of size 9, Index[4]: Stock of size 10
    private int[] blackShoesStock = new int[5];
    private int[] brownShoesStock = new int[5];

    public Shoes(String name, String id, double price,int totalStock ,int[] blackShoesStock, int[] brownShoesStock)
    {
        super(name, id, price, totalStock, Product.Category.SHOES);
        this.blackShoesStock = blackShoesStock;
        this.brownShoesStock = brownShoesStock;
    }

    //This retrieves the total stock(stockCount) from the lists
    public int totalStock()
    {
        int total = 0;
        for(int itemStock: blackShoesStock)
        {
            total = total + itemStock;
        }
        for(int itemStock: brownShoesStock)
        {
            total = total + itemStock;
        }
        return total;
    }

    //Determines if the products options recived is valid
    public boolean validOptions(String productOptions)
    {
        String[] prodOptions = productOptions.split(" ");
        boolean validSize = false;
        boolean validColor = false;

        if(prodOptions[0].equalsIgnoreCase("6")||prodOptions[0].equalsIgnoreCase("7")||prodOptions[0].equalsIgnoreCase("8")||prodOptions[0].equalsIgnoreCase("9")||prodOptions[0].equalsIgnoreCase("10"))
            validSize = true;

        if(prodOptions[1].equalsIgnoreCase("Black")||prodOptions[1].equalsIgnoreCase("Brown"))
            validColor = true;

        return validColor && validSize;
    }

    //Helper method - get the index of the list of the sizes(6, 7, 8, 9, 10)
    //If none returns -1
    public int getSizeIndex(String[] prodOptions)
    {
        if(prodOptions[0].equalsIgnoreCase("6"))
            return 0;
        else if(prodOptions[0].equalsIgnoreCase("7"))
            return 1;
        else if(prodOptions[0].equalsIgnoreCase("8"))
            return 2;
        else if(prodOptions[0].equalsIgnoreCase("9"))
            return 3;
        else if(prodOptions[0].equalsIgnoreCase("10"))
            return 4;  
        else
            return -1;

    }
    public int getStockCount(String productOptions)
    {
        String[] prodOptions = productOptions.split(" ");

        int index = this.getSizeIndex(prodOptions); //Gets the index of the shoe sizes if valid

        //If the colour is black check if valid shoe size, return the stock of the shoe size
        if(prodOptions[1].equalsIgnoreCase("Black"))
        {
            return blackShoesStock[index];
        }
        //If the colour is brown check if valid shoe size, return the stock of the shoe size
        else if(prodOptions[1].equalsIgnoreCase("Brown"))
        {
                return brownShoesStock[index];  
        }
        //Return the total stock of the shoe
        return super.getStockCount(productOptions);
    }

    public void setStockCount(int stockCount, String productOptions)
    {
        String[] prodOptions = productOptions.split(" ");
        int index = this.getSizeIndex(prodOptions); //Gets the index of the shoe sizes if valid 
        
        //If the colour is black check if valid shoe size, change the stock of the shoe size
        if(prodOptions[1].equalsIgnoreCase("Black"))
        {
            blackShoesStock[index] = stockCount; //Changes the current stock
        }
        //If the colour is brown check if valid shoe size, change the stock of the shoe size
        else if(prodOptions[1].equalsIgnoreCase("Brown"))
        {
            brownShoesStock[index] = stockCount; //Changes the current stock
        }
        // change the total stock of the shoe
        super.setStockCount(this.totalStock(), productOptions);
    }

    public void reduceStockCount(String productOptions) 
    {
        String[] prodOptions = productOptions.split(" ");//To get the indvidual productOptions
        int index = this.getSizeIndex(prodOptions); //Gets the index of the shoe sizes if valid

        //If the colour is black check if valid shoe size, change the stock of the shoe size
        if(prodOptions[1].equalsIgnoreCase("Black"))
        {
            blackShoesStock[index]--; //Changes the current stock
        }
        //If the colour is brown check if valid shoe size, change the stock of the shoe size
        else if(prodOptions[1].equalsIgnoreCase("Brown"))
        {
            brownShoesStock[index]--; //Changes the current stock
        }
        super.reduceStockCount(productOptions);
    }
    
    public void print()
    {
        super.print();
    }
}

